/*
 * File:   main.cpp
 * 
 * Author: João Pedro Carvalho Ferreira 2024.1.08.030
 * 
 * Discrição: Projeto para realizar operações em matrizes (trasposição, multiplicação, soma e média dos valores).
 * 
 * Created on 17 de junho de 2024, 12:30
 */

#ifndef MATRIZ_H
#define MATRIZ_H

typedef int TMatriz[256][256];

void transposta (TMatriz m1, int nl1, int nc1, TMatriz mt, int *nlt, int *nct);

int soma (TMatriz m1, int nl1, int nc1, TMatriz m2, int nl2, int nc2, TMatriz ms, int *nls, int *ncs);

int multiplicacao (TMatriz m1, int nl1, int nc1, TMatriz m2, int nl2, int nc2, TMatriz mm, int *nlm, int *ncm);

float media (TMatriz m, int nl, int nc);

#endif /* MATRIZ_H */

