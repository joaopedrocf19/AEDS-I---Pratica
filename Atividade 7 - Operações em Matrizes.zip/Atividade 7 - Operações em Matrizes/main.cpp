/*
 * File:   main.cpp
 * 
 * Author: João Pedro Carvalho Ferreira 2024.1.08.030
 * 
 * Discrição: Projeto para realizar operações em matrizes (trasposição, multiplicação, soma e média dos valores).
 * 
 * Created on 17 de junho de 2024, 12:30
 */

#include <cstdlib>
#include <iostream>
#include "matriz.h"

using namespace std;

int main(int argc, char** argv) {
    
    // atribuindo valores para as matrizes
    TMatriz matriz1 = {{ 1, 6, 2, 4, 3},
                       { 6, 4, 3, 10, 0},
                       { 1, 11, 0, -10, -8},
                       { 2, 3, 6, 14, -20},
                       { -8, 3, -4, -8, 7},
                       { -1, -6, -14, 0, -3},
                       { 8, 6, 5, 0, -1}};
    TMatriz matriz2 = {{ 14, -2, -7, -3, 0, 1, 10, 9, 11},
                       { 10, -4, -9, -5, 2, 3, 12, 11, 13},
                       { 13, -1, -6, -2, 5, 6, 8, 7, 9},
                       { 10, -2, 6, 2, -8, -5, 12, 14, -9},
                       { 8, 14, 1, 0, 1, 2, 16, 13, -19}};
    TMatriz matriz3 = {{ 4, 8, 7, 4, 12},
                       { -7, 8, 14, -9, 4},
                       { 4, 6, -1, 15, 7},
                       { -2, -10, -1, -7, 4},
                       { 9, -7, 15, 8, -3},
                       { 10, 0, 0, 1, 6},
                       { 5, 7, 1, -8, 6}};
    
    TMatriz matriz4;  // matriz que irá receber o resultada das operações
    
    int nl1, nc1, nl2, nc2, nl3, nc3, nl4, nc4;
    // atribuindo o número de linha e coluna de ca matriz, com exeção da matriz 4
    nl1 = 7;
    nc1 = 5;
    nl2 = 5;
    nc2 = 9;
    nl3 = 7;
    nc3 = 5;
    
    int i, j;
    
    // mostrando as matrizes 1, 2 e 3 na tela
    cout << "A matriz 1 é:" << endl;
    for (i = 0; i < nl1; i++){
        for (j = 0; j < nc1; j++){
            cout << matriz1[i][j] << "      ";
        }
        cout << endl;
    }
    cout << endl << "A matriz 2 é:" << endl;
    for (i = 0; i < nl2; i++){
        for (j = 0; j < nc2; j++){
            cout << matriz2[i][j] << "      ";
        }
        cout << endl;
    }
    cout << endl << "A matriz 3 é:" << endl;
    for (i = 0; i < nl3; i++){
        for (j = 0; j < nc3; j++){
            cout << matriz3[i][j] << "      ";
        }
        cout << endl;
    }
    
    // chamando a função trasposta para transpor a matiz 2
    transposta (matriz2, nl2, nc2, matriz4, &nl4, &nc4);
    // mostrando a matriz 2 transposta
    cout << endl << endl << endl << "I. A marriz transposta da matriz 2 é:" << endl;
    for (i = 0; i < nl4; i++){
        for (j = 0; j < nc4; j++){
            cout << matriz4[i][j] << "      ";
        }
        cout << endl;
    }
    
    // chamando a função soma para somar as matrizes 1 e 3́
    soma (matriz1, nl1, nc1, matriz3, nl3, nc3, matriz4, &nl4, &nc4);
    // mostrando a matriz resultante da soma das matrizes 1 e 3
    cout << endl << endl << endl << "II. A matriz resultante da soma das matrizes 1 e 3 é:" << endl;
    for (i = 0; i < nl4; i++){
        for (j = 0; j < nc4; j++){
            cout << matriz4[i][j] << "      ";
        }
        cout << endl;
    }
    
    // chamando a função nultiplicacao para multiplicar a matriz 1 pela matriz 2
    multiplicacao (matriz1, nl1, nc1, matriz2, nl2, nc2, matriz4, &nl4, &nc4);
    // mostrando a matriz resultante da multiplicação da matriz 1 pela matriz 2
    cout << endl << endl << endl << "III. A matriz resultante da multiplicação da matriz 1 pela matriz 2 é:" << endl;
    for (i = 0; i < nl4; i++){
        for (j = 0; j < nc4; j++){
            cout << matriz4[i][j] << "      ";
        }
        cout << endl;
    }
    
    // chamando a função media para calcular a média dos valores da matriz 1 e já mostrando o resultado
    cout << endl << endl << endl << "IV. A média dos valores da matriz 1 é " << media (matriz1, nl1, nc1) << ".";
    
    return 0;
}
