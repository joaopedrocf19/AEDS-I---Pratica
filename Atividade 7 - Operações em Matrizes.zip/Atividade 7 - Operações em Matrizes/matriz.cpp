/*
 * File:   main.cpp
 * 
 * Author: João Pedro Carvalho Ferreira 2024.1.08.030
 * 
 * Discrição: Projeto para realizar operações em matrizes (trasposição, multiplicação, soma e média dos valores).
 * 
 * Created on 17 de junho de 2024, 12:30
 */

#include <iostream>
#include "matriz.h"

using namespace std;

/*
 * Função para transpor uma matriz, resultando numa segunda.
 */
void transposta (TMatriz m1, int nl1, int nc1, TMatriz mt, int *nlt, int *nct){
    int i, j;
    for (i = 0; i < nl1; i++){
        for (j = 0; j < nc1; j++){
            mt[j][i] = m1[i][j];
        }
    }
    *nlt = nc1;
    *nct = nl1;
}

/*
 * Função para somar duas matrizes, resultando numa terceira.
 */
int soma (TMatriz m1, int nl1, int nc1, TMatriz m2, int nl2, int nc2, TMatriz ms, int *nls, int *ncs){
    // verificando se é possívei realizar a soma
    if (nl1 != nl2 or nc1 != nc2){
        return 1;
    }
    // realizando a soma
    int i, j;
    for (i = 0; i < nl1; i++){
        for (j = 0; j < nc1; j++){
            ms[i][j] = m1[i][j] + m2[i][j];
        }
    }
    *nls = nl1;
    *ncs = nc1;
    return 0;
}

/*
 * Função para multiplicar duas matrizes, resultando numa terceira.
 */
int multiplicacao (TMatriz m1, int nl1, int nc1, TMatriz m2, int nl2, int nc2, TMatriz mm, int *nlm, int *ncm){
    // verificando se é possívei realizar a multiplicação
    if (nc1 != nl2){
        return 1;
    }
    // realizando a multiplicação
    *nlm = nl1;
    *ncm = nc2;
    int i, j, k;
    for (i = 0; i < *nlm; i++){
        for (j = 0; j < *ncm; j++){
            mm[i][j] = 0;
        }
    }
    for (i = 0; i < *nlm; i++){
        for (j = 0; j < *ncm; j++){
            for (k = 0; k < *ncm; k++){
                mm[i][j] += m1[i][k] * m2[k][j];
            }
        }
    }
    return 0;
}

/*
 * Função para calcular a média dos valores de uma matriz.
 */
float media (TMatriz m, int nl, int nc){
    int i, j, soma;
    float media;
    soma = 0;
    for (i = 0; i < nl; i++){
        for (j = 0; j < nc; j++){
            soma += m[i][j];
        }
    }
    media = (float) soma / (nl * nc);
    // retornando com o valor da média
    return media;
}
