/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Pedro Carvalho Ferreira 2024.1.08.030
 *
 * Created on 20 de maio de 2024, 16:45
 */

#include <cstdlib>
#include <time.h>
#include <iostream>
#include <fstream>

using namespace std;

/*
 * Projeto para gerar um vetor de números aleatórios não repetidos
 */

const int TAM = 100000;

int main(int argc, char** argv) {

    int vet[TAM], i, deslo, nnovo, limite;
    
    srand (time(NULL));
    
    i=0;
    while (i<TAM){
        vet[i]=-1;
        i++;
    }
    
    i=0;
    nnovo=0;
    limite=TAM;
    while (nnovo<TAM){
        deslo=rand()%limite;
        i=(i+deslo)%TAM;
        if (vet[i] != -1){
            while (vet[i] != -1){
                i++;
                if (i>TAM-1){
                    i=0;
                }
            }
        }
        vet[i]=nnovo;
        limite--;
        nnovo++;
    }
    
    ofstream arquivo ("Numeros.txt");
    if (!arquivo.is_open()){
        cout<<"ERRO: arquivo não encontrado."<<endl;
        return 1;
    }
    
    i=0;
    while (i<TAM){
        arquivo<<vet[i]<<endl;
        i++;
    }
    arquivo.close();

    return 0;
}

