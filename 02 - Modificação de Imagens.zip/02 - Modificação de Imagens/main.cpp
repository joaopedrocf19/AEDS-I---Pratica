/* 
 * File:   main.cpp
 *
 * Author: Guilherme Oliveira Araujo 2024.1.08.011
 * Author: João Pedro Carvalho Ferreira 2024.1.08.030
 *  
 * Descrição: Projeto para modificar imagens (escurecer, clarear, binalizar, filtrar, negativar e criar ruídos).
 * 
 * Created on 18 de junho de 2024, 11:53
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <time.h>

using namespace std;

typedef int Timagem[404][600]; //não foi possível fazer estrutura maior, devido falha de segmentação

/*
 * Função para clarear ou escurecer uma imagem e enviar para um arquivo.
 */
void tonalidade (Timagem imagem, int nl, int nc, Timagem imagemtonalidade, float fator, string tipo, int limite){
    int i, j;
     for (i = 0; i < nl; i++){
        for (j = 0; j < nc; j++){
            imagemtonalidade[i][j] = imagem[i][j] * fator; 
            if (imagemtonalidade[i][j] > 255){
                imagemtonalidade[i][j] = 255;
            }
        }
    }
    ofstream arquivo2("stanfordtonalidade.txt");
    arquivo2 << tipo << endl << nc << " " << nl << endl << limite << endl;
    for (i = 0; i < nl; i++) {
        for (j = 0; j < nc; j++) {
            arquivo2 << imagemtonalidade[i][j] << " ";
        }
    }
    arquivo2.close();
}

/*
 * Função para encontrar o negativo de uma imagem e enviar para um arquivo.
 */
void negativa (Timagem imagem, int nl, int nc, Timagem imagemnegativa, string tipo, int limite){
    int i, j;
    for (i=0; i<nl; i++){
        for (j=0; j<nc; j++){
            imagemnegativa[i][j] = 255 - imagem[i][j];   
        }
    }
    ofstream arquivo3("stanfordnegativa.txt");
    arquivo3 << tipo << endl << nc << " " << nl << endl << limite << endl;
    for (i = 0; i < nl; i++) {
        for (j = 0; j < nc; j++) {
            arquivo3 << imagemnegativa[i][j] << " ";
        }
    }
    arquivo3.close();
}

/*
 * Função para binarizar uma imagem e enviar para um arquivo.
 */
void binarizar (Timagem imagem, int nl, int nc, int fator, Timagem imagembinarizada, string tipo, int limite){
    int i, j;
    for (i=0; i<nl; i++){
        for (j=0; j<nc; j++){
            if (imagem[i][j] <= fator){
                imagembinarizada[i][j]=0;
            }else{
                imagembinarizada[i][j]=255;
            }           
        }
    }
    ofstream arquivo4("stanfordbinarizada.txt");
    arquivo4 << tipo << endl << nc << " " << nl << endl << limite << endl;
    for (i = 0; i < nl; i++) {
        for (j = 0; j < nc; j++) {
            arquivo4 << imagembinarizada[i][j] << " ";
        }
    }
    arquivo4.close();
}

/*
 * Função para iconizar uma imagem e enviar para um arquivo.
 */
void iconizar (Timagem imagem, int nl, int nc, Timagem imagemiconizada, string tipo, int limite){
    int i, j, i2, j2, soma;
    for (i2=0; i2<nl; i2+=6){
        for (j2=0; j2<nc; j2+=9){
            for (i=i2, soma=0; i<i2+6; i++){
                for (j=j2; j<j2+9; j++){   
                    soma+=imagem[i][j];
                }       
            }
            imagemiconizada[i2/6][j2/9]=soma/36;
        }
    }
    ofstream arquivo5 ("stanfordiconizada.txt");
    arquivo5 << tipo << endl << 64 << " " << 64 << endl << limite << endl;
    for (i = 0; i < 64; i++) {
        for (j = 0; j < 64; j++) {
            arquivo5 << imagemiconizada[i][j] << " ";
        }
    }
    arquivo5.close();
}

/*
 * Função para criar ruídos em uma imagem e enviar para um arquivo.
 */
void ruidos (Timagem imagem, int nl, int nc, Timagem imagemruidos, string tipo, int limite){
    int i, j, conta;
    for (i=0; i<nl; i++){
        for (j=0; j<nc; j++){
            imagemruidos[i][j]=imagem[i][j];
        }
    }
    srand (time(NULL));
    for (conta=0; conta<3000; conta++){
        i = rand() % nl;
        j = rand() % nc;
        imagemruidos[i][j]=0;       
    }
    for (conta=0; conta<3000; conta++){
        i = rand() % nl;
        j = rand() % nc;
        imagemruidos[i][j]=255;       
    }
    ofstream arquivo6 ("stanfordruidos.txt");
    arquivo6 << tipo << endl << nc << " " << nl << endl << limite << endl;
    for (i = 0; i < nl; i++) {
        for (j = 0; j < nc; j++) {
            arquivo6 << imagemruidos[i][j] << " ";
        }
    }
    arquivo6.close();
}

/*
 * Função para aplicar um filtro a fim de suavizar uma imagem e enviar para um arquivo.
 */
void filtro (Timagem imagem, int nl, int nc, Timagem imagemfiltro, string tipo, int limite){
    int i, j, soma;
    for (i=0; i<nl; i++){
        for (j=0; j<nc; j++){
            imagemfiltro[i][j]=imagem[i][j];
        }
    }
    for (i=1; i<nl-1; i++){
        for (j=1; j<nc-1; j++){
            imagemfiltro[i][j] = (imagemfiltro[i-1][j-1] + imagemfiltro[i-1][j] + imagemfiltro[i-1][j+1] + imagemfiltro[i][j-1] + imagemfiltro[i][j+1] + imagemfiltro[i+1][j-1] + imagemfiltro[i+1][j] + imagemfiltro[i+1][j+1]) / 8;
        }
    }
    ofstream arquivo7 ("stanfordsuavizada.txt");
    arquivo7 << tipo << endl << nc << " " << nl << endl << limite << endl;
    for (i = 0; i < nl; i++) {
        for (j = 0; j < nc; j++) {
            arquivo7 << imagemfiltro[i][j] << " ";
        }
    }
    arquivo7.close();
}

int main (int argc, char** argv){
    int i, j, nl, nc, limite, opcao, opcao2, fator2;
    float fator;
    string tipo;
    Timagem imagem, imagemtonalidade, imagemnegativa, imagembinarizada, imagemiconizada, imagemruidos, imagemfiltro; 
    // abrindo o arquivo da imagem principal
    ifstream arquivo ("stanford.txt");
    if (!arquivo.is_open()){
        cout << " ERRO: arquivo não encontrado." << endl;
        return 1;
    }
    arquivo >> tipo >> nc >> nl >> limite;
    for (i = 0; i < nl; i++){
        for (j = 0; j < nc; j++){
            arquivo >> imagem[i][j];
        }
    }
    // fechando o arquivo
    arquivo.close(); 
    do{   
        // mostrando o menu do projeto
        cout<<" Escolha uma das opções abaixo:"<<endl;
        cout<<" Opção 0: Sair."<<endl;
        cout<<" Opção 1: Clarear ou Escurecer a imagem."<<endl;
        cout<<" Opção 2: Encontrar a imagem negativa."<<endl;
        cout<<" Opção 3: Binarizar a imagem por um determinado fator."<<endl;
        cout<<" Opção 4: Iconizar a imagem."<<endl;
        cout<<" Opção 5: Criar ruídos na imagem."<<endl;
        cout<<" Opção 6: Aplicar um filtro para suavizar a imagem."<<endl;
        cin>>opcao;
        cout<<endl;
        switch (opcao){ 
            // operações a serem realizadas dependendo da escolha feita pelo usuário
            case 0:
                cout<<endl<<" Saída realizada com sucesso!!!"; 
                break;
            case 1:
                //operações para alterar a tonalidade
                cout<<endl<<" Você deseja esclurecer ou clarear?"<<endl;   
                cout<<" Digite 1 para clarear ou 2 para escurecer: ";
                cin>>opcao2;
                while (opcao2!=1 and opcao2!=2){
                    cout<<endl<<" Opção incorreta. Digite novamente: ";
                    cin>>opcao2;
                }
                if (opcao2==1){
                    cout<<endl<<" Digite a porcentagem que deseja clarear: ";
                    cin>>fator;
                    while (fator<0 or fator>100){
                        cout<<" Porcentagem inválida. Digite novamente: ";
                        cin>>fator;
                    }
                    fator=1+(fator/100.0);
                }
                else{
                    cout<<endl<<" Digite a porcentagem que deseja escurecer: ";
                    cin>>fator;
                    while (fator<0 or fator>100){
                        cout<<endl<<" Porcentagem inválida. Digite novamente: ";
                        cin>>fator;
                    }
                    fator=1-(fator/100.0);
                }
                tonalidade (imagem, nl, nc, imagemtonalidade, fator, tipo, limite);               
                cout<<endl<<" Sua imagem foi alterada com sucesso!"<<endl<<endl<<endl;
                break;
            case 2:
                // operações para gerar a imagem negativa
                negativa (imagem, nl, nc, imagemnegativa, tipo, limite);
                cout<<endl<<" Sua imagem foi alterada com sucesso!"<<endl<<endl<<endl;
                break;
            case 3:
                //operações para binarizar a imagem
                cout<<endl<<" Digite um fator entre 0 a 255 para binarizar: ";
                cin>>fator2;
                while (fator2 < 0 or fator2 > 255){
                    cout<<" Fator inválido. Digite novamente: ";
                    cin>>fator2;
                }
                binarizar (imagem, nl, nc, fator2, imagembinarizada, tipo, limite);
                cout<<endl<<" Sua imagem foi alterada com sucesso!"<<endl<<endl<<endl;
                break;
            case 4:
                //opções para iconizar a imagem
                iconizar (imagem, nl, nc, imagemiconizada, tipo, limite);
                cout<<endl<<" Sua imagem foi alterada com sucesso!"<<endl<<endl<<endl;
                break;
            case 5:
                //operações para gerar ruídos na imagem
                ruidos (imagem, nl, nc, imagemruidos, tipo, limite);
                cout<<endl<<" Sua imagem foi alterada com sucesso!"<<endl<<endl<<endl;
                break;
            case 6:
                //operações para aplicar filtro na imagem
                filtro (imagem, nl, nc, imagemfiltro, tipo, limite);
                cout<<endl<<" Sua imagem foi alterada com sucesso!"<<endl<<endl<<endl;
                break;
            default:
                cout<<endl<<" Opção incorreta. Digite novamente. "<<endl<<endl<<endl;
        }
        //mostrando o menu ao usuario enquanto sua escolha for diferente de 0
    }while(opcao != 0);
    
    return 0;
}
