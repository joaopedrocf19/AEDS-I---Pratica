/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: João Pedro Carvalho Ferreira 2024.1.08.030
 *
 * Created on 17 de maio de 2024, 18:25
 */

#include <cstdlib>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include <math.h>

using namespace std;

/*
 * Projeto para manipular dados em um vetor de registros e realizar estatísticas.
 */

const int TAM = 100;

typedef struct{
    bool valido;
    string modelo;
    string marca;
    string tipo;
    int ano;
    int quilometragem;
    string potencia;
    string combustivel;
    string cambio;
    string direcao;
    string cor;
    string portas;
    string placa;
    float valor;
}veiculo;

int main(int argc, char** argv) {

    veiculo dados[TAM], busca;
    int i, j, qtde, opcao, parada, conta, escolha, somahatch, somasedan, somasuv, somapasseio, somapickup, somavan;
    int somadiesel, somagasolina, somaflex, somaquilometragem, conta3, conta4;
    float vminimo, vmaximo, qtdef, preco, preco2, conta2;
    string awx, opcao2, identificacao, identificacao2;

    ifstream arquivo ("BD_veiculos.txt");  // abrindo o arquivo com os dados dos veículos  
    if (!arquivo.is_open()){
        cout<<"ERRO: arquivo não encotrado."<<endl;
        return 1;
    }
    
    // passando os dados do arquivo para o vetor de registros 
    arquivo>>awx;  
    i=0;
    qtde=0;
    while (awx != "FIM"){
        dados[i].modelo=awx;
        arquivo>>dados[i].marca;
        arquivo>>dados[i].tipo;
        arquivo>>dados[i].ano;
        arquivo>>dados[i].quilometragem;
        arquivo>>dados[i].potencia;
        arquivo>>dados[i].combustivel;
        arquivo>>dados[i].cambio;
        arquivo>>dados[i].direcao;
        arquivo>>dados[i].cor;
        arquivo>>dados[i].portas;
        arquivo>>dados[i].placa;
        arquivo>>dados[i].valor;
        dados[i].valido=true;  // atribuindo verdadeiro para os campos válidos
        arquivo>>awx;
        i++;
        qtde++;
    }
    
    arquivo.close();  // fechando o arquivo
    
    while (i<TAM){
        dados[i].valido=false;  // atribuindo falso para os campos que não foram preenchindos com dados 
        i++;
    }
    
    cout<<endl<<"Escolha uma das opções abaixo:"<<endl<<endl;  // mostrando o menu de opções
    cout<<"Opção 1: Incluir um novo veículo na base de dados."<<endl;
    cout<<"Opção 2: Buscar um veículo pela sua placa, com opção de excluir da base de dados."<<endl;
    cout<<"Opção 3: Buscar veículos pelo tipo."<<endl;
    cout<<"Opção 4: Buscar veículos pelo câmbio."<<endl;
    cout<<"Opção 5: Buscar veículos por uma determinada faixa de valores."<<endl;
    cout<<"Opção 6: Visualizar o relatório do banco de dados."<<endl;
    cin>>opcao;

    do{
        switch (opcao){
            case 1:
                if (qtde<TAM){  // verificando se tem espaço disponível no vetor
                    // inserindo dados de um novo veículo no vetor
                    i=0;
                    parada=qtde;
                    while (parada == qtde){
                        if (dados[i].valido == false){  // encontrando campo inválido no vetor
                            cout<<endl<<endl<<"IMPORTANTE: Em caso de nomes compostos, utilize '_' para separar os termos."<<endl;  // informando o usuário sobre como ele deve escrever nomes compostos
                            cout<<endl<<"Digite o modelo do novo veículo:"<<endl;
                            cin>>dados[i].modelo;
                            cout<<endl<<"Digite a marca:"<<endl;
                            cin>>dados[i].marca;
                            cout<<endl<<"Digite a letra referente ao tipo:"<<endl;
                            do{
                               cout<<endl<<"Opção A: Hatch"<<endl;  // apresentando as opções de tipo
                               cout<<"Opção B: Sedan"<<endl;
                               cout<<"Opção C: Passeio"<<endl;
                               cout<<"Opção D: SUV"<<endl;
                               cout<<"Opção E: Pick-up"<<endl;
                               cout<<"Opção F: Van"<<endl;
                               cin>>opcao2;
                               escolha=1;
                               if (opcao2 == "A"){
                                   dados[i].tipo="Hatch";
                               }
                               else if (opcao2 == "B"){
                                   dados[i].tipo="Sedan";
                               }
                               else if (opcao2 == "C"){
                                   dados[i].tipo="Passeio";
                               }
                               else if (opcao2 == "D"){
                                   dados[i].tipo="SUV";
                               }
                               else if (opcao2 == "E"){
                                   dados[i].tipo="Pick-up";
                               }
                               else if (opcao2 == "F"){
                                   dados[i].tipo="Van";
                               }
                               else{
                                   cout<<endl<<"Opção inválida. Digite novamente:"<<endl;
                                   escolha=0;
                               }
                            }while (escolha != 1);
                            cout<<endl<<"Digite o ano:"<<endl;
                            cin>>dados[i].ano;
                            cout<<endl<<"Digite a quilometragem:"<<endl;
                            cin>>dados[i].quilometragem;
                            cout<<endl<<"Digite a potência do motor:"<<endl;
                            cin>>dados[i].potencia;
                            cout<<endl<<"Digite a letra refernte ao combustível:"<<endl;
                            do{
                                cout<<endl<<"Opção A: Diesel"<<endl;  // apresentando as opções de combutível
                                cout<<"Opção B: Gasolina"<<endl;
                                cout<<"Opção C: Flex"<<endl;
                                cin>>opcao2;
                                escolha=1;
                                if (opcao2 == "A"){
                                    dados[i].combustivel="Diesel";
                                }
                                else if (opcao2 == "B"){
                                    dados[i].combustivel="Gasolina";
                                }
                                else if (opcao2 == "C"){
                                    dados[i].combustivel="Flex";
                                }
                                else{
                                    cout<<endl<<"Opção inválida. Digite novamente:"<<endl;
                                    escolha=0;
                                }
                            }while (escolha != 1);
                            cout<<endl<<"Digite a letra referente ao tipo do câmbio:"<<endl;
                            do{
                                cout<<endl<<"Opção A: Automático"<<endl;  // apresentando as opções de câmbio 
                                cout<<"Opção B: Manual"<<endl;
                                cin>>opcao2;
                                escolha=1;
                                if (opcao2 == "A"){
                                    dados[i].cambio="Automático";
                                }
                                else if (opcao2 == "B"){
                                    dados[i].cambio="Manual";
                                }
                                else{
                                    cout<<endl<<"Opção inválida. Digite novamente:"<<endl;
                                    escolha=0;
                                }
                            }while (escolha != 1);
                            cout<<endl<<"Digite a letra referente ao tipo da direção:"<<endl;
                            do{
                                cout<<endl<<"Opção A: Simples"<<endl;  // apresentando as opções de direção 
                                cout<<"Opção B: Hidráulica"<<endl;
                                cout<<"Opção C: Elétrica"<<endl;
                                cin>>opcao2;
                                escolha=1;
                                if (opcao2 == "A"){
                                    dados[i].direcao="Simples";
                                }
                                else if (opcao2 == "B"){
                                    dados[i].direcao="Hidráulica";
                                }
                                else if (opcao2 == "C"){
                                    dados[i].direcao="Elétrica";
                                }
                                else{
                                    cout<<endl<<"Opção inválida. Digite novamente:"<<endl;
                                    escolha=0;
                                }
                            }while (escolha != 1);
                            cout<<endl<<"Digite a cor:"<<endl;
                            cin>>dados[i].cor;
                            cout<<endl<<"Digite a quantidade de portas:"<<endl;
                            cin>>dados[i].portas;
                            cout<<endl<<"Digite a placa:"<<endl;
                            cin>>dados[i].placa;
                            cout<<endl<<"Digite o valor:"<<endl;
                            cin>>dados[i].valor;
                            dados[i].valido=true;
                            qtde++;
                            cout<<endl<<"Dados incluídos com sucesso!"<<endl;
                        }
                        i++;
                    }
                }
                else{
                    cout<<endl<<endl<<"Sua base de dados não possui espaço para a inclusão de um novo veículo."<<endl;  // informando ao usuário, caso o vetor não tenha espaço disponível
                }
                break;
            case 2:
                cout<<endl<<endl<<"Digite a placa do veículo:"<<endl;
                cin>>busca.placa;
                i=0;
                j=0;
                parada=1;
                while (parada == 1 and j<qtde){
                    if (dados[i].valido == true){  // encontrando os campos válidos
                        if (dados[i].placa == busca.placa){  // encontrando o veículo com a placa digitada pelo usuário
                            cout<<endl<<"O veículo com a placa "<<busca.placa<<" possui os seguintes dados:"<<endl<<endl;  // apresentando os dados do veículo
                            cout<<"Modelo: "<<dados[i].modelo<<endl;
                            cout<<"Marca: "<<dados[i].marca<<endl;
                            cout<<"Tipo: "<<dados[i].tipo<<endl;
                            cout<<"Ano: "<<dados[i].ano<<endl;
                            cout<<"Quilometragem: "<<dados[i].quilometragem<<endl;
                            cout<<"Potência: "<<dados[i].potencia<<endl;
                            cout<<"Combustível: "<<dados[i].combustivel<<endl;
                            cout<<"Câmbio: "<<dados[i].cambio<<endl;
                            cout<<"Direção: "<<dados[i].direcao<<endl;
                            cout<<"Cor: "<<dados[i].cor<<endl;
                            cout<<"Portas: "<<dados[i].portas<<endl;
                            cout<<"Valor: R$ "<<dados[i].valor<<".00"<<endl;
                            parada=0;
                            cout<<endl<<"Se deseja excluir os dados deste veículo da base de dados, digite 'E'"<<endl;  // dando a opção de excluir os dados do veículo 
                            cout<<"Senão, dijite qualquer outra letra para retornar ao menu."<<endl;
                            cin>>opcao2;
                            if (opcao2 == "E"){
                                dados[i].valido=false;  // atribuindo falso ao campo, caso o usuário exclua os dados do veículo
                                qtde--;
                                cout<<endl<<"Dados excluídos com sucesso!"<<endl;
                            }
                        }
                        j++;
                    }
                    i++;
                }
                if (parada == 1){
                    cout<<endl<<"Nenhum veículo com a placa "<<busca.placa<<" foi encontrado."<<endl;
                }
                break;
            case 3:
                cout<<endl<<endl<<"Digite o tipo de veículo que você está bucando:"<<endl;
                cin>>busca.tipo;
                cout<<endl<<"Buscando veículos tipo "<<busca.tipo<<"..."<<endl<<endl;
                i=0;
                j=0;
                conta=0;
                while (j<qtde){
                    if (dados[i].valido == true){  // encontrando os campos válidos
                        if (dados[i].tipo == busca.tipo){   // encontrando veículos do tipo digitado pelo usuário 
                            cout<<"Modelo: "<<dados[i].modelo<<endl;  // apresentando os dados dos veículos 
                            cout<<"Marca: "<<dados[i].marca<<endl;
                            cout<<"Ano: "<<dados[i].ano<<endl;
                            cout<<"Quilometragem: "<<dados[i].quilometragem<<endl;
                            cout<<"Potência: "<<dados[i].potencia<<endl;
                            cout<<"Combustível: "<<dados[i].combustivel<<endl;
                            cout<<"Câmbio: "<<dados[i].cambio<<endl;
                            cout<<"Direção: "<<dados[i].direcao<<endl;
                            cout<<"Cor: "<<dados[i].cor<<endl;
                            cout<<"Portas: "<<dados[i].portas<<endl;
                            cout<<"Placa: "<<dados[i].placa<<endl;
                            cout<<"Valor: R$ "<<dados[i].valor<<".00"<<endl<<endl;
                            conta++;
                        }
                        j++;
                    }
                    i++;
                }
                if (conta>0){
                    cout<<endl<<"Foi(am) encontrado(s) "<<conta<<" veículo(s) tipo "<<busca.tipo<<"."<<endl;
                }
                else{
                    cout<<endl<<"Nenhum veículo tipo "<<busca.tipo<<" foi encontrado."<<endl;
                }
                break;
            case 4:
                cout<<endl<<endl<<"Digite o tipo de câmbio dos veículos que você está bucando:"<<endl;
                cin>>busca.cambio;
                cout<<endl<<"Buscando veículos com câmbio "<<busca.cambio<<"..."<<endl<<endl;
                i=0;
                j=0;
                conta=0;
                while (j<qtde){
                    if (dados[i].valido == true){  // encontrando os campos válidos 
                        if (dados[i].cambio == busca.cambio){  // encontrando veículos com o mesmo tipo de câmbio digitado pelo usuário 
                            cout<<"Modelo: "<<dados[i].modelo<<endl;  // apresentando os dados dos veículos 
                            cout<<"Marca: "<<dados[i].marca<<endl;
                            cout<<"Tipo: "<<dados[i].tipo<<endl;
                            cout<<"Ano: "<<dados[i].ano<<endl;
                            cout<<"Quilometragem: "<<dados[i].quilometragem<<endl;
                            cout<<"Potência: "<<dados[i].potencia<<endl;
                            cout<<"Combustível: "<<dados[i].combustivel<<endl;
                            cout<<"Direção: "<<dados[i].direcao<<endl;
                            cout<<"Cor: "<<dados[i].cor<<endl;
                            cout<<"Portas: "<<dados[i].portas<<endl;
                            cout<<"Placa: "<<dados[i].placa<<endl;
                            cout<<"Valor: R$ "<<dados[i].valor<<".00"<<endl<<endl;
                            conta++;
                        }
                        j++;
                    }
                    i++;
                }
                if (conta>0){
                    cout<<endl<<"Foi(am) encontrado(s) "<<conta<<" veículo(s) com câmbio "<<busca.cambio<<"."<<endl;
                }
                else{
                    cout<<endl<<"Nenhum veículo com câmbio "<<busca.cambio<<" foi encontrado."<<endl;
                }
                break;
            case 5:
                cout<<endl<<endl<<"Digite o valor mínimo dos veículos que você está bucando:"<<endl;
                cin>>vminimo;
                cout<<endl<<"Agora digite o valor máximo:"<<endl;
                cin>>vmaximo;
                cout<<endl<<"Buscando veículos que estão na faixa de preço R$"<<vminimo<<"-R$"<<vmaximo<<"..."<<endl<<endl;
                i=0;
                j=0;
                conta=0;
                while (j<qtde){
                    if (dados[i].valido == true){  // encontrando os campos válidos 
                        if (dados[i].valor >= vminimo and dados[i].valor <= vmaximo){  // encontrando veículos que estão na faixa de preço desejada pelo usuário 
                            cout<<"Modelo: "<<dados[i].modelo<<endl;  // apresentando os dados dos veículos 
                            cout<<"Marca: "<<dados[i].marca<<endl;
                            cout<<"Tipo: "<<dados[i].tipo<<endl;
                            cout<<"Ano: "<<dados[i].ano<<endl;
                            cout<<"Quilometragem: "<<dados[i].quilometragem<<endl;
                            cout<<"Potência: "<<dados[i].potencia<<endl;
                            cout<<"Combustível: "<<dados[i].combustivel<<endl;
                            cout<<"Câmbio: "<<dados[i].cambio<<endl;
                            cout<<"Direção: "<<dados[i].direcao<<endl;
                            cout<<"Cor: "<<dados[i].cor<<endl;
                            cout<<"Portas: "<<dados[i].portas<<endl;
                            cout<<"Placa: "<<dados[i].placa<<endl;
                            cout<<"Valor: R$ "<<dados[i].valor<<".00"<<endl<<endl;
                            conta++;
                        }
                        j++;
                    }
                    i++;
                }
                if (conta>0){
                    cout<<endl<<"Foi(am) encontrado(s) "<<conta<<" veículo(s) na faixa de preço R$"<<vminimo<<"-R$"<<vmaximo<<"."<<endl;
                }
                else{
                    cout<<endl<<"Nenhum veículo na faixa de preço R$"<<vminimo<<"-R$"<<vmaximo<<" foi encontrado."<<endl;
                }
                break;
            case 6:
                cout<<endl<<endl<<"Relatório do banco de dados:"<<endl<<endl;  // apresentando estátisticas do banco de dados
                i=0;
                j=0;
                somahatch=0;
                somasedan=0;
                somasuv=0;
                somapasseio=0;
                somapickup=0;
                somavan=0;
                somadiesel=0;
                somagasolina=0;
                somaflex=0;
                preco=10000000;
                preco2=0;
                conta2=0;
                somaquilometragem=0;
                conta3=0;
                conta4=0;
                while (j<qtde){
                    if (dados[i].valido == true){
                        // calculando a quantidade de veículos em cada categoria de tipo
                        if (dados[i].tipo == "Hatch"){
                            somahatch++;
                        }
                        else if (dados[i].tipo == "Sedan"){
                            somasedan++;
                        }
                        else if (dados[i].tipo == "SUV"){
                            somasuv++;
                        }
                        else if (dados[i].tipo == "Passeio"){
                            somapasseio++;
                        }
                        else if (dados[i].tipo == "Pick-up"){
                            somapickup++;
                        }
                        else{
                            somavan++;
                        }
                        // calculando a quantidade de veículos em cada categoria de combustível
                        if (dados[i].combustivel == "Diesel"){
                            somadiesel++;
                        }
                        else if (dados[i].combustivel == "Gasolina"){
                            somagasolina++;
                        }
                        else{
                            somaflex++;
                        }
                        // encontrando o veículo 1.0 mais barato
                        if (dados[i].potencia == "1.0" and dados[i].valor < preco){
                            identificacao=dados[i].placa;
                            preco=dados[i].valor;
                            conta3++;
                        }
                        // encontrando o veículo mais caro com direção hidráulica e câmbio automático
                        if (dados[i].valor > preco2 and dados[i].direcao == "Hidráulica" and dados[i].cambio == "Automático"){
                            identificacao2=dados[i].placa;
                            preco2=dados[i].valor;
                            conta4++;
                        }
                        // encontrando a quantidade e o total de quilometragem dos veículos com 5 anos ou mais
                        if (dados[i].ano <= 2019){
                            somaquilometragem += dados[i].quilometragem;
                            conta2++;
                        }
                        j++;
                    }
                    i++;
                }
                qtdef=qtde;
                // mostrando as porcentagens de veículos em cada categoria de tipo
                cout<<"I. Porcentagens de veículos nas categorias de tipo:"<<endl;
                cout<<"Hatch: "<<somahatch/qtdef*100.0<<"%"<<endl;
                cout<<"Sedan: "<<somasedan/qtdef*100.0<<"%"<<endl;
                cout<<"SUV: "<<somasuv/qtdef*100.0<<"%"<<endl;
                cout<<"Passeio: "<<somapasseio/qtdef*100.0<<"%"<<endl;
                cout<<"Pick-up: "<<somapickup/qtdef*100.0<<"%"<<endl;
                cout<<"Van: "<<somavan/qtdef*100.0<<"%"<<endl;
                // mostrando as porcentagens de veículos em cada categoria de combutível
                cout<<endl<<"II. Porcentagens de veículos nas categorias de combutível:"<<endl;
                cout<<"Diesel: "<<somadiesel/qtdef*100.0<<"%"<<endl;
                cout<<"Gasolina: "<<somagasolina/qtdef*100.0<<"%"<<endl;
                cout<<"Flex: "<<somaflex/qtdef*100.0<<"%"<<endl;
                // mostrando placa, valor do veículo 1.0 mais barato e o preço da prestação do financiamento em 60 meses com juros atuais (1.015% a.m)
                if (conta3>0){
                    cout<<endl<<"III. Placa, valor e preço da prestação do financiamento em 60 meses com juros atuais do veículo 1.0 mais barato:"<<endl;
                    cout<<"Placa: "<<identificacao<<endl;
                    cout<<"Valor: R$ "<<preco<<".00"<<endl;
                    cout<<"Prestação: R$ "<<(preco*pow(1.015, 60))/60<<endl;
                }
                // mostrando placa, valor do veículo mais caro com direção hidráulica e câmbio automático e o preço estimado do seguro
                if (conta4>0){
                    cout<<endl<<"IV. Placa, valor e preço estimado do seguro do veículo mais caro com direção hidráulica e câmbio automático:"<<endl;
                    cout<<"Placa: "<<identificacao2<<endl;
                    cout<<"Valor: R$ "<<preco2<<".00"<<endl;
                    cout<<"Seguro: R$ "<<preco2*6.6/100<<endl;  // porcentagem de 6.6% sobre o valor do veículo
                }
                // mostrando a quatidade e a média de quilometragem dos veículos com 5 anos ou mais
                if (conta2>0){
                    cout<<endl<<"V. Qnatidade e média de quilometragem dos veículos com 5 anos ou mais:"<<endl;
                    cout<<"Qantidade: "<<conta2<<endl;
                    cout<<"Média: "<<somaquilometragem/conta2<<endl;
                }
                break;
            default:
                cout<<endl<<"Opção inválida."<<endl;
        }
        cout<<endl<<endl<<"Escolha novamente uma das opções abaixo:"<<endl<<endl;  // mostrando novamente o menu de opções
        cout<<"Opção 1: Incluir um novo veículo na base de dados."<<endl;
        cout<<"Opção 2: Buscar um veículo pela sua placa, com opção de excluir da base de dados."<<endl;
        cout<<"Opção 3: Buscar veículos pelo tipo."<<endl;
        cout<<"Opção 4: Buscar veículos pelo câmbio."<<endl;
        cout<<"Opção 5: Buscar veículos por uma determinada faixa de valores."<<endl;
        cout<<"Opção 6: Visualizar o relatório do banco de dados."<<endl;
        cout<<"Opção 7: Finalizar."<<endl;
        cin>>opcao;
    }while(opcao != 7);
    
    cout<<endl<<"Salvando base dados..."<<endl;
    
    ofstream arquivo2 ("BD_veiculos.txt");  // abrindo novamente o arquivo 
    if (!arquivo2.is_open()){
        cout<<"ERRO: arquivo não encontrado."<<endl;
        return 2;
    }
    
    i=0;
    while (qtde>0){
        if (dados[i].valido == true){  // encontrando os campos válidos 
            arquivo2<<dados[i].modelo<<" ";  // passando os dados do vetor para o arquivo
            arquivo2<<dados[i].marca<<" ";
            arquivo2<<dados[i].tipo<<" ";
            arquivo2<<dados[i].ano<<" ";
            arquivo2<<dados[i].quilometragem<<" ";
            arquivo2<<dados[i].potencia<<" ";
            arquivo2<<dados[i].combustivel<<" ";
            arquivo2<<dados[i].cambio<<" ";
            arquivo2<<dados[i].direcao<<" ";
            arquivo2<<dados[i].cor<<" ";
            arquivo2<<dados[i].portas<<" ";
            arquivo2<<dados[i].placa<<" ";
            arquivo2<<dados[i].valor<<endl;
            qtde--;
        }
        i++;
    }
    arquivo2<<"FIM";
    arquivo2.close();  // fechando o arquivo 
    
    cout<<endl<<"   Base de dados salva com sucesso!!!";
    
    return 0;
}

